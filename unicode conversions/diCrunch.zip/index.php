<?PHP

require_once('diCrunch.php');

?>