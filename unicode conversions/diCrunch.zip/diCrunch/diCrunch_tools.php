<?PHP


$op .= <<<CWS

<div class="wrapper">
<h2>diCrunch Tools &nbsp; &middot; &nbsp; <a href="{$_SERVER['PHP_SELF']}">Home</a> &raquo;</h2>


<div class="preferenceheading">
<b>Macro Tool</b>
</div>
<div class="preferencefield">
<b>Create conversion macros</b> from the diCrunch character sets for use with your word processor: <b><a href="{$_SERVER['PHP_SELF']}?act=macro">Macro Tool</a> &raquo;</b>
</div>


<div class="preferenceheading">
<b>Feedback Module</b>
</div>
<div class="preferencefield">
<b>For feedback or support </b>, use the feedback module for contacting the developers: <b><a href="{$_SERVER['PHP_SELF']}?act=feedback">Feedback Module</a> &raquo;</b>
</div>






</div>

CWS;


?>